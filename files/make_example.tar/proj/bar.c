int bar() {
    return 25;
}
