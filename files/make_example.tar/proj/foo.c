#include <stdio.h>

void foo() {
    puts("Foo is the first metasyntactic variable");
}
