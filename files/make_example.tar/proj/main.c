#include "foo.h"
#include "bar.h"
#include <stdio.h>

int main() {
    foo();
    printf("bar yields %d\n", bar());
}
