#include "foo.h"
#include "bar.h"
#include <stdio.h>

int main() {
    puts("==============================");
    printf("Testing foo:\n");
    foo();
    puts("==============================");
    
    puts("\n");
    
    puts("==============================");
    printf("Testing bar:\n");
    printf("%d\n", bar());
    puts("==============================");
}
