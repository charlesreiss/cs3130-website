#ifndef TIMING_H_
#define TIMING_H_

long measure_once(int *presult, char *p, int (*f)(char*));

#endif
