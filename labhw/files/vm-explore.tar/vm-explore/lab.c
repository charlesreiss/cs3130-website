#define _GNU_SOURCE
#include "util.h"
#include <stdio.h>      // for printf
#include <stdlib.h>     // for atoi (and malloc() which you'll likely use)
#include <sys/mman.h>   // for mmap() which you'll likely use


void labStuff(int which) {
if (which == 0) {
/* do nothing */
} else if (which == 1) {

} else if (which == 2) {

} else if (which == 3) {

} else if (which == 4) {

}
}

int main(int argc, char **argv) {
int which = 0;
if (argc > 1) {
which = atoi(argv[1]);
} else {
fprintf(stderr, "Usage: %s NUMBER\n", argv[0]);
return 1;
}
printf("Memory layout:\n");
print_maps(stdout);
printf("\n");
printf("Initial state:\n");
force_load();
struct memory_record r1, r2;
record_memory_record(&r1);
print_memory_record(stdout, NULL, &r1);
printf("---\n");

printf("Running labStuff(%d)...\n", which);

labStuff(which);

printf("---\n");
printf("Afterwards:\n");
record_memory_record(&r2);
print_memory_record(stdout, &r1, &r2);
print_maps(stdout);
return 0;
}
